/*
┏━━━━━━━━━━━━━━━┓  
┃ RIKZZ BASE - WHATSAPP     
┣━━━━━━━━━━━━━━━┛
┃♕ Creator: ryzzxd           
┃♕ AI Helper: ChatGPT             
┃♔ Version: 1.0.0                   
┗━━━━━━━━━━━━━━━┛
*/
//========RIKZZ========
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6285279206033"] 
global.namabot = 'ryzzxd'
//======================
global.mess = { 
owner: 'waduhh!, lu bukan owner gw bg',
premium: 'anda bukan user premium',
succes: 'done bang'
}
//======================