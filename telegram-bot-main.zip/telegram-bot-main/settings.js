const settings = {
  ownerName: 'Moon4kAstrepheous', // Ganti dengan nama owner lu
  botToken: '7832617600:AAF5eiSNIO0bB3ZYT-a5ehCUTB_yAyiBcNk', // Ganti dengan token bot Telegram lu
  owner: '8161426686', //OWNER user id
};

module.exports = settings;
